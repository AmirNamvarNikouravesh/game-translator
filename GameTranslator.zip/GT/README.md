# مترجم بازی (انگلیسی به فارسی)
1. این پوشه را در یک مخزن GitHub آپلود کنید (Upload files، با پوشه .github).
2. تب Actions ← Build APK ← Run workflow.
3. بعد از اتمام، از بخش Artifacts فایل GameTranslator-APK را دانلود و نصب کنید.
