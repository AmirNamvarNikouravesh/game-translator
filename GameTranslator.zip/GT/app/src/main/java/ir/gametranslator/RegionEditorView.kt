package ir.gametranslator

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.view.MotionEvent
import android.view.View
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

/**
 * Full-screen editor for the translation region.
 * - Drag on an empty area: draw a new rectangle.
 * - Drag inside the rectangle: move it.
 * - Drag an edge or corner: resize it.
 */
class RegionEditorView(ctx: Context, init: RectF) : View(ctx) {
    val rect = RectF(init)

    private val d = resources.displayMetrics.density
    private val slop = 30 * d
    private val minSz = 40 * d
    private val dim = Paint().apply { color = 0x99000000.toInt() }
    private val border = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = 0xFFFFD400.toInt(); style = Paint.Style.STROKE; strokeWidth = 2.5f * d
    }
    private val handle = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xFFFFD400.toInt() }
    private val txt = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE; textSize = 14 * d; textAlign = Paint.Align.CENTER
        setShadowLayer(4f, 0f, 0f, Color.BLACK)
    }

    private var mode = 0            // 0 none, 1 move, 2 draw, 3 resize
    private var eL = false; private var eR = false; private var eT = false; private var eB = false
    private var ax = 0f; private var ay = 0f; private var lx = 0f; private var ly = 0f

    override fun onDraw(c: Canvas) {
        val w = width.toFloat(); val h = height.toFloat()
        c.drawRect(0f, 0f, w, rect.top, dim)
        c.drawRect(0f, rect.bottom, w, h, dim)
        c.drawRect(0f, rect.top, rect.left, rect.bottom, dim)
        c.drawRect(rect.right, rect.top, w, rect.bottom, dim)
        c.drawRect(rect, border)
        val r = 6 * d
        val cx = rect.centerX(); val cy = rect.centerY()
        for ((x, y) in listOf(
            rect.left to rect.top, rect.right to rect.top, rect.left to rect.bottom, rect.right to rect.bottom,
            cx to rect.top, cx to rect.bottom, rect.left to cy, rect.right to cy
        )) c.drawCircle(x, y, r, handle)
        c.drawText("کادر را دورِ متن گفتگو بکشید (نام کاراکتر را بیرون بگذارید)", w / 2f, 120 * d, txt)
        c.drawText("داخل کادر = جابه‌جایی · لبه‌ها و گوشه‌ها = تغییر اندازه", w / 2f, 142 * d, txt)
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        val x = e.x; val y = e.y
        val w = width.toFloat(); val h = height.toFloat()
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                val inY = y > rect.top - slop && y < rect.bottom + slop
                val inX = x > rect.left - slop && x < rect.right + slop
                eL = inY && abs(x - rect.left) < slop
                eR = inY && abs(x - rect.right) < slop
                eT = inX && abs(y - rect.top) < slop
                eB = inX && abs(y - rect.bottom) < slop
                mode = when {
                    eL || eR || eT || eB -> 3
                    rect.contains(x, y) -> 1
                    else -> { ax = x; ay = y; rect.set(x, y, x, y); 2 }
                }
                lx = x; ly = y
            }
            MotionEvent.ACTION_MOVE -> {
                when (mode) {
                    1 -> {
                        val nl = (rect.left + x - lx).coerceIn(0f, max(0f, w - rect.width()))
                        val nt = (rect.top + y - ly).coerceIn(0f, max(0f, h - rect.height()))
                        rect.offsetTo(nl, nt)
                    }
                    2 -> rect.set(
                        min(ax, x).coerceIn(0f, w), min(ay, y).coerceIn(0f, h),
                        max(ax, x).coerceIn(0f, w), max(ay, y).coerceIn(0f, h)
                    )
                    3 -> {
                        if (eL) rect.left = x.coerceIn(0f, max(0f, rect.right - minSz))
                        if (eR) rect.right = x.coerceIn(min(w, rect.left + minSz), w)
                        if (eT) rect.top = y.coerceIn(0f, max(0f, rect.bottom - minSz))
                        if (eB) rect.bottom = y.coerceIn(min(h, rect.top + minSz), h)
                    }
                }
                lx = x; ly = y
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> mode = 0
        }
        invalidate()
        return true
    }
}
