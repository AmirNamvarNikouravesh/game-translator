package ir.gametranslator

import kotlinx.coroutines.*
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.util.concurrent.ConcurrentHashMap

data class Config(val engine: String, val apiKey: String, val model: String, val intervalMs: Long)

object Translator {
    private val cache = ConcurrentHashMap<String, String>()

    suspend fun translate(cfg: Config, texts: List<String>): Map<String, String> =
        withContext(Dispatchers.IO) {
            val todo = texts.distinct().filter { !cache.containsKey(it) }
            if (todo.isNotEmpty()) {
                val out = if (cfg.engine == "gemini" && cfg.apiKey.isNotBlank()) gemini(cfg, todo) else google(todo)
                todo.forEachIndexed { i, s -> cache[s] = out[i] }
            }
            texts.associateWith { cache[it] ?: it }
        }

    private suspend fun google(todo: List<String>): List<String> = coroutineScope {
        todo.map { async { googleOne(it) } }.awaitAll()
    }

    private fun googleOne(text: String): String {
        val url = URL("https://translate.googleapis.com/translate_a/single?client=gtx&sl=en&tl=fa&dt=t&q=" +
                URLEncoder.encode(text, "UTF-8"))
        val c = url.openConnection() as HttpURLConnection
        c.connectTimeout = 8000; c.readTimeout = 8000
        c.setRequestProperty("User-Agent", "Mozilla/5.0")
        if (c.responseCode != 200) throw Exception("Google HTTP ${c.responseCode}")
        val body = c.inputStream.bufferedReader().readText()
        val arr = JSONArray(body).getJSONArray(0)
        val sb = StringBuilder()
        for (i in 0 until arr.length()) {
            val seg = arr.getJSONArray(i)
            if (!seg.isNull(0)) sb.append(seg.getString(0))
        }
        return sb.toString().ifBlank { text }
    }

    private fun gemini(cfg: Config, todo: List<String>): List<String> {
        val prompt = "You translate English video-game UI and dialogue text into natural, fluent, " +
                "colloquial Persian (Farsi), the way Iranian gamers would read it. Keep it concise. " +
                "Keep numbers and proper names (players, places) as they are. " +
                "Input is a JSON array of strings. Return ONLY a JSON array of the same length " +
                "with the Persian translations in the same order.\n" + JSONArray(todo).toString()
        val body = JSONObject()
            .put("contents", JSONArray().put(JSONObject().put("parts",
                JSONArray().put(JSONObject().put("text", prompt)))))
            .put("generationConfig", JSONObject()
                .put("responseMimeType", "application/json").put("temperature", 0.3))
        val c = URL("https://generativelanguage.googleapis.com/v1beta/models/${cfg.model}:generateContent")
            .openConnection() as HttpURLConnection
        c.requestMethod = "POST"
        c.connectTimeout = 10000; c.readTimeout = 20000
        c.doOutput = true
        c.setRequestProperty("Content-Type", "application/json")
        c.setRequestProperty("x-goog-api-key", cfg.apiKey)
        c.outputStream.use { it.write(body.toString().toByteArray()) }
        if (c.responseCode != 200) {
            val err = c.errorStream?.bufferedReader()?.readText()?.take(200) ?: ""
            throw Exception("Gemini HTTP ${c.responseCode} $err")
        }
        val resp = JSONObject(c.inputStream.bufferedReader().readText())
        val text = resp.getJSONArray("candidates").getJSONObject(0)
            .getJSONObject("content").getJSONArray("parts").getJSONObject(0).getString("text")
        val res = JSONArray(text)
        if (res.length() != todo.size) throw Exception("پاسخ ناقص از مدل")
        return List(todo.size) { res.getString(it) }
    }
}
