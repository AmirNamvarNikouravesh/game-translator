package ir.gametranslator

import kotlinx.coroutines.*
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.util.concurrent.ConcurrentHashMap

data class Config(
    val engine: String, val apiKey: String, val model: String,
    val settleMs: Long, val game: String
)

class HttpErr(val code: Int, msg: String) : Exception(msg)

object Translator {
    const val DEFAULT_MODEL = "gemini-3.8-flash"
    private val FALLBACKS = listOf("gemini-3.6-flash", "gemini-3.5-flash-lite", "gemini-3.1-flash-lite")

    private val cache = ConcurrentHashMap<String, String>()
    private val dead = ConcurrentHashMap.newKeySet<String>()   // models that returned 404
    private val history = ArrayDeque<String>()                 // previous English lines (context)

    suspend fun translate(cfg: Config, texts: List<String>): Map<String, String> =
        withContext(Dispatchers.IO) {
            val todo = texts.distinct().filter { !cache.containsKey(it) }
            if (todo.isNotEmpty()) {
                val out = if (cfg.engine == "gemini" && cfg.apiKey.isNotBlank()) gemini(cfg, todo) else google(todo)
                todo.forEachIndexed { i, s -> cache[s] = out[i] }
                synchronized(history) {
                    todo.forEach { history.addLast(it) }
                    while (history.size > 8) history.removeFirst()
                }
            }
            texts.associateWith { cache[it] ?: it }
        }

    // ---------------- Google (free) ----------------
    private suspend fun google(todo: List<String>): List<String> = coroutineScope {
        todo.map { async { googleOne(it) } }.awaitAll()
    }

    private fun googleOne(text: String): String {
        val url = URL("https://translate.googleapis.com/translate_a/single?client=gtx&sl=en&tl=fa&dt=t&q=" +
                URLEncoder.encode(text, "UTF-8"))
        val c = url.openConnection() as HttpURLConnection
        c.connectTimeout = 8000; c.readTimeout = 8000
        c.setRequestProperty("User-Agent", "Mozilla/5.0")
        if (c.responseCode != 200) throw Exception("Google HTTP ${c.responseCode}")
        val arr = JSONArray(c.inputStream.bufferedReader().readText()).getJSONArray(0)
        val sb = StringBuilder()
        for (i in 0 until arr.length()) {
            val seg = arr.getJSONArray(i)
            if (!seg.isNull(0)) sb.append(seg.getString(0))
        }
        return sb.toString().ifBlank { text }
    }

    // ---------------- Gemini ----------------
    private fun buildPrompt(cfg: Config, todo: List<String>): String {
        val ctx = synchronized(history) { history.toList() }
        val game = cfg.game.ifBlank { "unknown" }
        return """
You are a professional video game localizer translating English into Persian (Farsi) for Iranian players.
Game / genre: $game

Rules:
- Translate meaning, tone and register, not word for word. Dialogue: natural, colloquial Persian that matches the speaker (casual, formal, sarcastic, archaic, slang). Menus, buttons and HUD: short, standard gaming terms.
- Idioms, jokes, phrasal verbs and slang: use an equivalent Persian expression, never a literal translation.
- The text comes from OCR: silently fix obvious OCR mistakes (broken words, 0/O, l/I confusion, missing spaces) before translating.
- Keep proper names, item and skill names, numbers, units and placeholders ({0}, %s, <b>) unchanged. Short abbreviations like HP, XP, MP may stay in Latin.
- The items are from the same screen in reading order and may be consecutive parts of one sentence or conversation. Use them as context for each other.
- If an item is meaningless (noise or symbols), return it unchanged.
- Output Persian only. No explanations.

Previous lines for context only (do NOT translate them): ${JSONArray(ctx)}

Input is a JSON array of strings. Return ONLY a JSON array of the same length with the translations in the same order.
${JSONArray(todo)}
""".trimIndent()
    }

    private fun gemini(cfg: Config, todo: List<String>): List<String> {
        val prompt = buildPrompt(cfg, todo)
        val chain = (listOf(cfg.model.ifBlank { DEFAULT_MODEL }) + FALLBACKS).distinct().filter { it !in dead }
        var first: HttpErr? = null
        for (m in chain) {
            try {
                return geminiCall(cfg, m, prompt, todo.size)
            } catch (e: HttpErr) {
                if (first == null) first = e
                if (e.code == 404) dead.add(m)
                if (e.code !in listOf(404, 429, 403, 503)) throw e
            }
        }
        throw first ?: Exception("هیچ مدلی در دسترس نیست")
    }

    private fun geminiCall(cfg: Config, model: String, prompt: String, n: Int): List<String> {
        val body = JSONObject()
            .put("contents", JSONArray().put(JSONObject().put("parts",
                JSONArray().put(JSONObject().put("text", prompt)))))
            .put("generationConfig", JSONObject()
                .put("responseMimeType", "application/json").put("temperature", 0.3))
        val c = URL("https://generativelanguage.googleapis.com/v1beta/models/$model:generateContent")
            .openConnection() as HttpURLConnection
        c.requestMethod = "POST"
        c.connectTimeout = 10000; c.readTimeout = 30000
        c.doOutput = true
        c.setRequestProperty("Content-Type", "application/json")
        c.setRequestProperty("x-goog-api-key", cfg.apiKey)
        c.outputStream.use { it.write(body.toString().toByteArray()) }
        val code = c.responseCode
        if (code != 200) {
            val err = c.errorStream?.bufferedReader()?.readText()?.take(160) ?: ""
            val msg = when (code) {
                429 -> "محدودیت تعداد درخواست Gemini (کمی صبر کنید) [$model]"
                400, 403 -> "کلید API یا مدل نامعتبر است ($code) [$model] $err"
                404 -> "مدل پیدا نشد [$model]"
                else -> "Gemini HTTP $code [$model] $err"
            }
            throw HttpErr(code, msg)
        }
        val resp = JSONObject(c.inputStream.bufferedReader().readText())
        val parts = resp.getJSONArray("candidates").getJSONObject(0)
            .getJSONObject("content").getJSONArray("parts")
        val sb = StringBuilder()
        for (i in 0 until parts.length()) sb.append(parts.getJSONObject(i).optString("text", ""))
        val res = JSONArray(sb.toString().trim().removePrefix("```json").removeSuffix("```").trim())
        if (res.length() != n) throw Exception("پاسخ ناقص از مدل")
        return List(n) { res.getString(it) }
    }
}
