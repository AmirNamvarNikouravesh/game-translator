package ir.gametranslator

import android.app.*
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Rect
import android.graphics.RectF
import android.graphics.drawable.GradientDrawable
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.Image
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.*
import android.util.DisplayMetrics
import android.view.*
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import kotlinx.coroutines.*
import kotlinx.coroutines.tasks.await
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

class OverlayService : Service() {
    private lateinit var wm: WindowManager
    private val main = Handler(Looper.getMainLooper())
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private var projection: MediaProjection? = null
    private var vd: VirtualDisplay? = null
    private var reader: ImageReader? = null
    private val lock = Any()
    private var held: Image? = null
    private val bgThread = HandlerThread("cap").apply { start() }
    private val bgHandler by lazy { Handler(bgThread.looper) }
    private var sw = 0; private var sh = 0; private var dpi = 0

    private val recognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
    private lateinit var canvasView: TranslationView
    private lateinit var container: LinearLayout
    private lateinit var fab: TextView
    private lateinit var menu: LinearLayout
    private lateinit var autoBtn: TextView
    private lateinit var regionBtn: TextView
    private var editor: View? = null

    // translation region (stored as fractions of the screen so it survives rotation)
    @Volatile private var regionOn = false
    @Volatile private var regionF: RectF? = null

    private var busy = false
    private var auto = false
    private var autoJob: Job? = null
    private var lastSig = ""
    private var lastErr = ""
    @Volatile private var runCounter = 0
    private var clearJob: Job? = null
    private lateinit var fabLp: WindowManager.LayoutParams

    companion object { const val STEP = 8; const val THR = 3 }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    override fun onBind(i: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == "STOP") { stopSelf(); return START_NOT_STICKY }
        if (projection != null) return START_NOT_STICKY
        startFg()
        @Suppress("DEPRECATION")
        val data = intent?.getParcelableExtra<Intent>("data")
        val code = intent?.getIntExtra("code", 0) ?: 0
        if (data == null) { stopSelf(); return START_NOT_STICKY }
        val mpm = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        projection = mpm.getMediaProjection(code, data)
        projection!!.registerCallback(object : MediaProjection.Callback() {
            override fun onStop() { main.post { stopSelf() } }
        }, main)
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        setupDisplay()
        buildOverlay()
        return START_NOT_STICKY
    }

    private fun startFg() {
        val nm = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
        nm.createNotificationChannel(NotificationChannel("gt", "مترجم بازی", NotificationManager.IMPORTANCE_LOW))
        val stopPi = PendingIntent.getService(this, 0,
            Intent(this, OverlayService::class.java).setAction("STOP"),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
        @Suppress("DEPRECATION")
        val n = Notification.Builder(this, "gt").setContentTitle("مترجم بازی فعال است")
            .setSmallIcon(android.R.drawable.ic_menu_edit)
            .addAction(android.R.drawable.ic_menu_close_clear_cancel, "توقف", stopPi).build()
        if (Build.VERSION.SDK_INT >= 29)
            startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)
        else startForeground(1, n)
    }

    // ---------- screen capture ----------
    private fun metrics(): DisplayMetrics {
        val dm = DisplayMetrics()
        (getSystemService(DISPLAY_SERVICE) as DisplayManager)
            .getDisplay(Display.DEFAULT_DISPLAY).getRealMetrics(dm)
        return dm
    }

    private fun newReader(w: Int, h: Int): ImageReader {
        val r = ImageReader.newInstance(w, h, PixelFormat.RGBA_8888, 3)
        r.setOnImageAvailableListener({ rd ->
            synchronized(lock) {
                val img = try { rd.acquireLatestImage() } catch (e: Exception) { null }
                if (img != null) { held?.close(); held = img }
            }
        }, bgHandler)
        return r
    }

    private fun setupDisplay() {
        val dm = metrics()
        sw = dm.widthPixels; sh = dm.heightPixels; dpi = dm.densityDpi
        reader = newReader(sw, sh)
        vd = projection!!.createVirtualDisplay("cap", sw, sh, dpi,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, reader!!.surface, null, null)
    }

    /** returns true if screen size/rotation changed */
    private fun ensureDisplay(): Boolean {
        val dm = metrics()
        if (dm.widthPixels == sw && dm.heightPixels == sh) return false
        synchronized(lock) { held?.close(); held = null }
        val old = reader
        sw = dm.widthPixels; sh = dm.heightPixels; dpi = dm.densityDpi
        reader = newReader(sw, sh)
        vd?.resize(sw, sh, dpi)
        vd?.surface = reader!!.surface
        old?.close()
        return true
    }

    private fun toBitmap(img: Image): Bitmap {
        val p = img.planes[0]
        p.buffer.rewind()
        val bw = p.rowStride / p.pixelStride
        val bmp = Bitmap.createBitmap(bw, img.height, Bitmap.Config.ARGB_8888)
        bmp.copyPixelsFromBuffer(p.buffer)
        return if (bw == img.width) bmp else Bitmap.createBitmap(bmp, 0, 0, img.width, img.height)
    }

    private suspend fun grabFrame(): Bitmap? {
        repeat(10) {
            val b = withContext(Dispatchers.Default) { synchronized(lock) { held?.let { toBitmap(it) } } }
            if (b != null) return b
            delay(100)
        }
        return null
    }

    // ---------- main translate cycle ----------
    private fun loadConfig(): Config {
        val p = getSharedPreferences("cfg", Context.MODE_PRIVATE)
        return Config(p.getString("engine", "google")!!, p.getString("key", "")!!,
            p.getString("model", Translator.DEFAULT_MODEL)!!, p.getInt("settle", 600).toLong(),
            p.getString("game", "")!!, p.getInt("fontScale", 130), p.getInt("clearSec", 0),
            p.getInt("minWordsV2", 1), p.getBoolean("casual", true), p.getBoolean("ignoreNames", true))
    }

    // ---------- translation region ----------
    private fun loadRegion() {
        val p = getSharedPreferences("cfg", Context.MODE_PRIVATE)
        regionOn = p.getBoolean("regionOn", false)
        regionF = if (p.contains("rl")) RectF(p.getFloat("rl", 0f), p.getFloat("rt", 0f),
            p.getFloat("rr", 1f), p.getFloat("rb", 1f)) else null
    }

    private fun saveRegion() {
        val e = getSharedPreferences("cfg", Context.MODE_PRIVATE).edit().putBoolean("regionOn", regionOn)
        regionF?.let { e.putFloat("rl", it.left).putFloat("rt", it.top).putFloat("rr", it.right).putFloat("rb", it.bottom) }
        e.apply()
    }

    /** Region in pixels for an image of the given size, or null when region mode is off / invalid. */
    private fun regionPx(w: Int, h: Int): Rect? {
        if (!regionOn) return null
        val f = regionF ?: return null
        val l = (f.left * w).toInt().coerceIn(0, w - 1)
        val t = (f.top * h).toInt().coerceIn(0, h - 1)
        val r = (f.right * w).toInt().coerceIn(l + 1, w)
        val b = (f.bottom * h).toInt().coerceIn(t + 1, h)
        return if (r - l < 16 || b - t < 16) null else Rect(l, t, r, b)
    }

    private fun refreshRegionBtn() {
        regionBtn.text = if (regionOn) "کادر ترجمه: روشن ✓" else "کادر ترجمه: خاموش"
    }

    private fun setRegionOn(on: Boolean) {
        if (on && regionF == null) { openRegionEditor(); return }
        regionOn = on; saveRegion(); refreshRegionBtn()
        clearJob?.cancel(); clearTranslation()
        toast(if (on) "ترجمه فقط داخل کادر انجام می‌شود" else "ترجمه کل صفحه")
    }

    private fun openRegionEditor() {
        if (editor != null) return
        setMenu(false)
        clearJob?.cancel(); clearTranslation()
        container.visibility = View.INVISIBLE
        val dm = metrics()
        val sw0 = dm.widthPixels.toFloat(); val sh0 = dm.heightPixels.toFloat()
        val init = regionF?.let { RectF(it.left * sw0, it.top * sh0, it.right * sw0, it.bottom * sh0) }
            ?: RectF(sw0 * 0.12f, sh0 * 0.68f, sw0 * 0.88f, sh0 * 0.92f)
        val view = RegionEditorView(this, init)

        fun btn(t: String, color: Int, click: () -> Unit) = TextView(this).apply {
            text = t; setTextColor(Color.WHITE); textSize = 14f; gravity = Gravity.CENTER
            setPadding(dp(18), dp(10), dp(18), dp(10))
            background = GradientDrawable().apply { cornerRadius = dp(12).toFloat(); setColor(color) }
            setOnClickListener { click() }
        }
        val bar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL; layoutDirection = View.LAYOUT_DIRECTION_RTL
            addView(btn("✓ تأیید", 0xFF2E9E5B.toInt()) {
                val r = view.rect
                if (r.width() < dp(40) || r.height() < dp(24)) { toast("کادر خیلی کوچک است"); return@btn }
                regionF = RectF(r.left / view.width, r.top / view.height, r.right / view.width, r.bottom / view.height)
                regionOn = true; saveRegion(); refreshRegionBtn()
                closeRegionEditor()
                toast("کادر ذخیره شد. ترجمه فقط داخل کادر انجام می‌شود")
            }, LinearLayout.LayoutParams(-2, -2).apply { marginEnd = dp(10) })
            addView(btn("✕ لغو", 0xFFB23A3A.toInt()) { closeRegionEditor() })
        }
        val root = FrameLayout(this).apply {
            addView(view, FrameLayout.LayoutParams(-1, -1))
            addView(bar, FrameLayout.LayoutParams(-2, -2, Gravity.TOP or Gravity.CENTER_HORIZONTAL)
                .apply { topMargin = dp(40) })
        }
        val ep = WindowManager.LayoutParams(-1, -1, overlayType(),
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                    WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS, PixelFormat.TRANSLUCENT)
        if (Build.VERSION.SDK_INT >= 28)
            ep.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
        wm.addView(root, ep)
        editor = root
    }

    private fun closeRegionEditor() {
        editor?.let { try { wm.removeView(it) } catch (_: Exception) {} }
        editor = null
        if (::container.isInitialized) container.visibility = View.VISIBLE
        clearTranslation()
    }

    private fun toast(t: String) = Toast.makeText(this, t, Toast.LENGTH_SHORT).show()

    private class Para(var rect: Rect, var text: String, var lines: Int, var lineH: Int)

    private class Blk(val rect: Rect, val text: String, val n: Int)

    // ---------- character-name filter ----------
    /** Looks like a speaker name: 1-3 capitalised words, short, no sentence punctuation. */
    private fun isNameText(t: String): Boolean {
        val s = t.trim()
        if (s.length !in 2..24) return false
        if (!s.all { it.isLetter() || it == ' ' || it == '\'' || it == '-' }) return false
        val words = s.split(Regex("\\s+"))
        return words.size <= 3 && words.all { it[0].isUpperCase() }
    }

    private fun knownNames(): MutableSet<String> =
        getSharedPreferences("cfg", Context.MODE_PRIVATE).getStringSet("names", emptySet())!!.toMutableSet()

    private fun learnName(n: String) {
        val set = knownNames()
        if (set.size >= 200 || !set.add(n.trim().lowercase())) return
        getSharedPreferences("cfg", Context.MODE_PRIVATE).edit().putStringSet("names", set).apply()
    }

    /**
     * Converts OCR blocks to plain blocks (shifted by the region offset) and drops the speaker
     * name that games print above the dialogue, so only the spoken text gets translated.
     */
    private fun buildBlocks(blocks: List<com.google.mlkit.vision.text.Text.TextBlock>,
                            ignoreNames: Boolean, ox: Int, oy: Int): List<Blk> {
        val known = if (ignoreNames) knownNames() else mutableSetOf<String>()
        val items = mutableListOf<Blk>()
        for (b in blocks) {
            val r = b.boundingBox ?: continue
            val lines = b.lines.filter { it.boundingBox != null }
            if (ignoreNames && lines.size >= 2) {
                // name and dialogue were grouped by OCR into one block: first line is the name
                val l0 = lines[0]; val t0 = l0.text.trim()
                val w0 = l0.boundingBox!!.width(); val w1 = lines[1].boundingBox!!.width()
                val rest = lines.drop(1)
                val isName = isNameText(t0) &&
                        (t0.lowercase() in known || (t0.split(Regex("\\s+")).size <= 2 && w0 < 0.7f * w1))
                if (isName) {
                    val rr = Rect(rest[0].boundingBox!!)
                    rest.forEach { rr.union(it.boundingBox!!) }
                    rr.offset(ox, oy)
                    val txt = rest.joinToString(" ") { it.text }.replace("\n", " ").trim()
                    if (wordCount(txt) >= 3) learnName(t0)
                    items.add(Blk(rr, txt, rest.size))
                    continue
                }
            }
            val rr = Rect(r); rr.offset(ox, oy)
            items.add(Blk(rr, b.text.replace("\n", " ").trim(), max(1, b.lines.size)))
        }
        if (ignoreNames) {
            // a name that OCR kept as its own one-line block, sitting just above the dialogue
            val out = items.filter { it.n == 1 && isNameText(it.text) }.filter { c ->
                val h = c.rect.height()
                val body = items.any { o ->
                    o !== c && o.rect.top >= c.rect.top + h / 2 && o.rect.top - c.rect.bottom <= h * 2.2 &&
                            abs(o.rect.left - c.rect.left) <= h * 3 && wordCount(o.text) >= 3
                }
                if (body) learnName(c.text)
                body || c.text.lowercase() in known
            }.toSet()
            items.removeAll { it in out }
        }
        return items.sortedWith(compareBy({ it.rect.top }, { it.rect.left }))
    }

    /** Merge OCR blocks that are really one paragraph (a sentence wrapped over several lines). */
    private fun mergeBlocks(blocks: List<Blk>): List<Para> {
        val paras = mutableListOf<Para>()
        for (b in blocks) {
            val r = b.rect
            val n = max(1, b.n)
            val lh = max(1, r.height() / n)
            val t = b.text
            val target = paras.firstOrNull { p ->
                val gap = r.top - p.rect.bottom
                val hOverlap = min(p.rect.right, r.right) - max(p.rect.left, r.left)
                val minW = min(p.rect.width(), r.width())
                gap >= -lh / 2 && gap <= lh * 1.0 && hOverlap > 0.3 * minW &&
                        lh >= p.lineH * 0.7 && lh <= p.lineH * 1.4
            }
            if (target == null) paras.add(Para(Rect(r), t, n, lh))
            else {
                target.rect.union(r)
                target.text = target.text + " " + t
                target.lineH = (target.lineH * target.lines + lh * n) / (target.lines + n)
                target.lines += n
            }
        }
        return paras
    }

    private fun wordCount(t: String) = t.trim().split(Regex("\\s+")).size

    private suspend fun runOnce(isAuto: Boolean) {
        if (busy) return
        busy = true
        try {
            val cfg = loadConfig()
            val changed = ensureDisplay()
            val hadOverlay = canvasView.hasItems()
            if (hadOverlay) canvasView.visibility = View.INVISIBLE   // so our own overlay isn't OCR'd
            if (changed) delay(500) else if (hadOverlay) delay(170)
            val full = grabFrame()
            canvasView.visibility = View.VISIBLE                      // show old translation again right away
            if (full == null) { toast("تصویر صفحه گرفته نشد"); return }
            // only the selected region is OCR'd (when region mode is on)
            val rg = regionPx(full.width, full.height)
            val bmp = if (rg != null) Bitmap.createBitmap(full, rg.left, rg.top, rg.width(), rg.height()) else full
            val res = recognizer.process(InputImage.fromBitmap(bmp, 0)).await()
            val raw = res.textBlocks.filter { b ->
                b.boundingBox != null && b.text.length >= 2 && b.text.any { it in 'A'..'Z' || it in 'a'..'z' }
            }
            val blks = buildBlocks(raw, cfg.ignoreNames, rg?.left ?: 0, rg?.top ?: 0)
            val paras = mergeBlocks(blks).filter { wordCount(it.text) >= cfg.minWords }
            val texts = paras.map { it.text }
            val sig = texts.joinToString("|")
            if (texts.isEmpty()) {
                canvasView.setItems(emptyList()); lastSig = ""
                if (!isAuto) toast(if (blks.isEmpty()) "متن انگلیسی پیدا نشد"
                    else "متن پیدا شد ولی کمتر از «حداقل کلمه» تنظیمات است")
                return
            }
            if (isAuto && sig == lastSig) return
            val map = Translator.translate(cfg, texts)
            canvasView.scale = cfg.fontScale / 100f
            canvasView.setItems(paras.mapIndexed { i, pr ->
                TranslationView.Item(pr.rect, map[texts[i]] ?: texts[i], pr.lines)
            })
            lastSig = sig
            clearJob?.cancel()
            if (!isAuto && cfg.clearSec > 0) clearJob = scope.launch {
                delay(cfg.clearSec * 1000L); clearTranslation()
            }
            lastErr = ""
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            val m = e.message ?: e.javaClass.simpleName
            if (m != lastErr) toast("خطا: $m")
            lastErr = m
        } finally {
            canvasView.visibility = View.VISIBLE
            busy = false
            runCounter++
        }
    }

    private fun clearTranslation() {
        canvasView.setItems(emptyList()); lastSig = ""; runCounter++   // runCounter++ makes auto mode re-baseline
    }

    private fun setMenu(show: Boolean) {
        menu.visibility = if (show) View.VISIBLE else View.GONE
        val lp = fabLp
        if (show) {
            val dm = metrics()
            lp.width = dp(220)
            lp.x = lp.x.coerceAtMost(dm.widthPixels - dp(224)).coerceAtLeast(0)
            lp.y = lp.y.coerceAtMost(dm.heightPixels - dp(56 + 5 * 46 + 24)).coerceAtLeast(0)
        } else lp.width = WindowManager.LayoutParams.WRAP_CONTENT
        wm.updateViewLayout(container, lp)
    }

    // ---------- smart auto mode ----------
    private fun sampleFrame(): ByteArray? = synchronized(lock) {
        val img = held ?: return@synchronized null
        val p = img.planes[0]; val buf = p.buffer; val rs = p.rowStride; val ps = p.pixelStride
        // with region mode on, only watch the region (animations elsewhere don't trigger OCR)
        val rg = regionPx(img.width, img.height) ?: Rect(0, 0, img.width, img.height)
        val gw = rg.width() / STEP; val gh = rg.height() / STEP
        if (gw <= 0 || gh <= 0) return@synchronized null
        val out = ByteArray(gw * gh)
        for (gy in 0 until gh) {
            val y = rg.top + gy * STEP + STEP / 2
            for (gx in 0 until gw) {
                val i = y * rs + (rg.left + gx * STEP + STEP / 2) * ps
                val lum = (buf.get(i).toInt() and 0xFF) + 2 * (buf.get(i + 1).toInt() and 0xFF) +
                        (buf.get(i + 2).toInt() and 0xFF)
                out[gy * gw + gx] = (lum shr 2).toByte()
            }
        }
        out
    }

    /** Counts cells that changed while being "quiet" (not part of a constant animation). */
    private fun diffQuiet(a: ByteArray, b: ByteArray, act: FloatArray): Int {
        var q = 0
        for (i in a.indices) {
            if (abs((a[i].toInt() and 0xFF) - (b[i].toInt() and 0xFF)) > THR) {
                if (act[i] < 0.6f) q++
                act[i] = min(act[i] + 1f, 4f)
            } else act[i] *= 0.85f
        }
        return q
    }

    /**
     * Cheap watcher: samples the screen ~3x/second without OCR. Areas that move constantly
     * (character idle animation, particles) are learned and ignored. OCR + translation run
     * only after something that was still starts changing and then settles (e.g. new dialogue).
     */
    private suspend fun smartLoop() = coroutineScope {
        try {
            var need = true                                  // translate right after start
            val t0 = SystemClock.elapsedRealtime()
            var needSince = t0 - 10_000
            var lastMove = t0 - 10_000
            var prev: ByteArray? = null
            var act = FloatArray(0)
            var seen = runCounter
            while (isActive) {
                delay(300)
                if (busy) continue
                if (runCounter != seen) {                    // a translation/clear just happened: re-baseline
                    delay(300)
                    prev = withContext(Dispatchers.Default) { sampleFrame() }
                    act = FloatArray(prev?.size ?: 0)
                    seen = runCounter; need = false
                    continue
                }
                val cur = withContext(Dispatchers.Default) { sampleFrame() } ?: continue
                val now = SystemClock.elapsedRealtime()
                val p = prev
                if (p == null || p.size != cur.size) { prev = cur; act = FloatArray(cur.size); continue }
                val quiet = withContext(Dispatchers.Default) { diffQuiet(p, cur, act) }
                prev = cur
                val minCells = max(20, cur.size / 1500)
                if (quiet >= minCells) { if (!need) { need = true; needSince = now }; lastMove = now }
                else if (need && quiet >= minCells / 3) lastMove = now
                if (need && (now - lastMove >= loadConfig().settleMs || now - needSince >= 6000)) runOnce(true)
            }
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            toast("خطا در حالت خودکار: ${e.message}")
        }
    }

    private fun setAuto(on: Boolean) {
        auto = on
        autoJob?.cancel()
        fab.text = if (on) "خودکار" else "ترجمه"
        (fab.background as GradientDrawable).setColor(if (on) 0xFF2E9E5B.toInt() else 0xFF2D6BFF.toInt())
        autoBtn.text = if (on) "حالت خودکار هوشمند: روشن ✓" else "حالت خودکار هوشمند: خاموش"
        if (on) { toast("حالت خودکار روشن شد"); autoJob = scope.launch { smartLoop() } }
    }

    // ---------- overlay UI ----------
    private fun overlayType() = WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY

    private fun buildOverlay() {
        canvasView = TranslationView(this)
        val cp = WindowManager.LayoutParams(-1, -1, overlayType(),
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                    WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT)
        if (Build.VERSION.SDK_INT >= 28)
            cp.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
        wm.addView(canvasView, cp)

        fab = TextView(this).apply {
            text = "ترجمه"; setTextColor(Color.WHITE); textSize = 12f; gravity = Gravity.CENTER
            background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(0xFF2D6BFF.toInt()) }
            alpha = 0.88f
        }
        autoBtn = menuItem("حالت خودکار هوشمند: خاموش") { setAuto(!auto); setMenu(false) }
        loadRegion()
        regionBtn = menuItem("") { setRegionOn(!regionOn); setMenu(false) }
        refreshRegionBtn()
        menu = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; visibility = View.GONE
            addView(autoBtn)
            addView(menuItem("✏ رسم / ویرایش کادر ترجمه") { openRegionEditor() })
            addView(regionBtn)
            addView(menuItem("پاک کردن ترجمه") { clearJob?.cancel(); clearTranslation(); setMenu(false) })
            addView(menuItem("⏹ توقف و خروج") { stopSelf() })
        }
        container = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            addView(fab, LinearLayout.LayoutParams(dp(56), dp(56)))
            addView(menu)
        }
        val lp = WindowManager.LayoutParams(-2, -2, overlayType(),
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT).apply { gravity = Gravity.TOP or Gravity.START; x = dp(8); y = dp(160) }
        fabLp = lp
        wm.addView(container, lp)

        var dx = 0f; var dy = 0f; var sx = 0; var sy = 0; var moved = false; var longFired = false
        val longRun = Runnable {
            if (!moved) { longFired = true; setMenu(menu.visibility == View.GONE) }
        }
        fab.setOnTouchListener { _, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    dx = e.rawX; dy = e.rawY; sx = lp.x; sy = lp.y; moved = false; longFired = false
                    main.postDelayed(longRun, 600)
                }
                MotionEvent.ACTION_MOVE -> {
                    if (abs(e.rawX - dx) > 12 || abs(e.rawY - dy) > 12) { moved = true; main.removeCallbacks(longRun) }
                    if (moved) {
                        lp.x = sx + (e.rawX - dx).toInt(); lp.y = sy + (e.rawY - dy).toInt()
                        wm.updateViewLayout(container, lp)
                    }
                }
                MotionEvent.ACTION_UP -> {
                    main.removeCallbacks(longRun)
                    if (!moved && !longFired) {
                        if (menu.visibility == View.VISIBLE) setMenu(false)
                        else if (canvasView.hasItems()) { clearJob?.cancel(); clearTranslation() }   // tap = hide translation
                        else scope.launch { runOnce(false) }
                    }
                }
            }
            true
        }
    }

    private fun menuItem(t: String, onClick: () -> Unit) = TextView(this).apply {
        text = t; setTextColor(Color.WHITE); textSize = 13f
        setPadding(dp(14), dp(10), dp(14), dp(10))
        background = GradientDrawable().apply { cornerRadius = dp(10).toFloat(); setColor(0xEE10161E.toInt()) }
        layoutParams = LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(6) }
        gravity = Gravity.CENTER; layoutDirection = View.LAYOUT_DIRECTION_RTL; setSingleLine()
        setOnClickListener { onClick() }
    }

    override fun onDestroy() {
        autoJob?.cancel(); scope.cancel()
        try { editor?.let { wm.removeView(it) } } catch (_: Exception) {}
        try { wm.removeView(container); wm.removeView(canvasView) } catch (_: Exception) {}
        synchronized(lock) { held?.close(); held = null }
        vd?.release(); reader?.close(); projection?.stop()
        bgThread.quitSafely()
        super.onDestroy()
    }
}
