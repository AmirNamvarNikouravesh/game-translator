package ir.gametranslator

import android.app.*
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.Image
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.*
import android.util.DisplayMetrics
import android.view.*
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import kotlinx.coroutines.*
import kotlinx.coroutines.tasks.await
import kotlin.math.abs

class OverlayService : Service() {
    private lateinit var wm: WindowManager
    private val main = Handler(Looper.getMainLooper())
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private var projection: MediaProjection? = null
    private var vd: VirtualDisplay? = null
    private var reader: ImageReader? = null
    private val lock = Any()
    private var held: Image? = null
    private val bgThread = HandlerThread("cap").apply { start() }
    private val bgHandler by lazy { Handler(bgThread.looper) }
    private var sw = 0; private var sh = 0; private var dpi = 0

    private val recognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
    private lateinit var canvasView: TranslationView
    private lateinit var container: LinearLayout
    private lateinit var fab: TextView
    private lateinit var menu: LinearLayout
    private lateinit var autoBtn: TextView

    private var busy = false
    private var auto = false
    private var autoJob: Job? = null
    private var lastSig = ""
    private var lastErr = ""
    @Volatile private var runCounter = 0
    private var clearJob: Job? = null
    private lateinit var fabLp: WindowManager.LayoutParams

    companion object { const val STEP = 8; const val THR = 6; const val RATIO = 0.0015f }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    override fun onBind(i: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == "STOP") { stopSelf(); return START_NOT_STICKY }
        if (projection != null) return START_NOT_STICKY
        startFg()
        @Suppress("DEPRECATION")
        val data = intent?.getParcelableExtra<Intent>("data")
        val code = intent?.getIntExtra("code", 0) ?: 0
        if (data == null) { stopSelf(); return START_NOT_STICKY }
        val mpm = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        projection = mpm.getMediaProjection(code, data)
        projection!!.registerCallback(object : MediaProjection.Callback() {
            override fun onStop() { main.post { stopSelf() } }
        }, main)
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        setupDisplay()
        buildOverlay()
        return START_NOT_STICKY
    }

    private fun startFg() {
        val nm = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
        nm.createNotificationChannel(NotificationChannel("gt", "مترجم بازی", NotificationManager.IMPORTANCE_LOW))
        val stopPi = PendingIntent.getService(this, 0,
            Intent(this, OverlayService::class.java).setAction("STOP"),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
        @Suppress("DEPRECATION")
        val n = Notification.Builder(this, "gt").setContentTitle("مترجم بازی فعال است")
            .setSmallIcon(android.R.drawable.ic_menu_edit)
            .addAction(android.R.drawable.ic_menu_close_clear_cancel, "توقف", stopPi).build()
        if (Build.VERSION.SDK_INT >= 29)
            startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)
        else startForeground(1, n)
    }

    // ---------- screen capture ----------
    private fun metrics(): DisplayMetrics {
        val dm = DisplayMetrics()
        (getSystemService(DISPLAY_SERVICE) as DisplayManager)
            .getDisplay(Display.DEFAULT_DISPLAY).getRealMetrics(dm)
        return dm
    }

    private fun newReader(w: Int, h: Int): ImageReader {
        val r = ImageReader.newInstance(w, h, PixelFormat.RGBA_8888, 3)
        r.setOnImageAvailableListener({ rd ->
            synchronized(lock) {
                val img = try { rd.acquireLatestImage() } catch (e: Exception) { null }
                if (img != null) { held?.close(); held = img }
            }
        }, bgHandler)
        return r
    }

    private fun setupDisplay() {
        val dm = metrics()
        sw = dm.widthPixels; sh = dm.heightPixels; dpi = dm.densityDpi
        reader = newReader(sw, sh)
        vd = projection!!.createVirtualDisplay("cap", sw, sh, dpi,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, reader!!.surface, null, null)
    }

    /** returns true if screen size/rotation changed */
    private fun ensureDisplay(): Boolean {
        val dm = metrics()
        if (dm.widthPixels == sw && dm.heightPixels == sh) return false
        synchronized(lock) { held?.close(); held = null }
        val old = reader
        sw = dm.widthPixels; sh = dm.heightPixels; dpi = dm.densityDpi
        reader = newReader(sw, sh)
        vd?.resize(sw, sh, dpi)
        vd?.surface = reader!!.surface
        old?.close()
        return true
    }

    private fun toBitmap(img: Image): Bitmap {
        val p = img.planes[0]
        p.buffer.rewind()
        val bw = p.rowStride / p.pixelStride
        val bmp = Bitmap.createBitmap(bw, img.height, Bitmap.Config.ARGB_8888)
        bmp.copyPixelsFromBuffer(p.buffer)
        return if (bw == img.width) bmp else Bitmap.createBitmap(bmp, 0, 0, img.width, img.height)
    }

    private suspend fun grabFrame(): Bitmap? {
        repeat(10) {
            val b = withContext(Dispatchers.Default) { synchronized(lock) { held?.let { toBitmap(it) } } }
            if (b != null) return b
            delay(100)
        }
        return null
    }

    // ---------- main translate cycle ----------
    private fun loadConfig(): Config {
        val p = getSharedPreferences("cfg", Context.MODE_PRIVATE)
        return Config(p.getString("engine", "google")!!, p.getString("key", "")!!,
            p.getString("model", Translator.DEFAULT_MODEL)!!, p.getInt("settle", 600).toLong(),
            p.getString("game", "")!!, p.getInt("fontScale", 130), p.getInt("clearSec", 0),
            p.getInt("minWords", 2), p.getBoolean("casual", true))
    }

    private fun toast(t: String) = Toast.makeText(this, t, Toast.LENGTH_SHORT).show()

    private suspend fun runOnce(isAuto: Boolean) {
        if (busy) return
        busy = true
        try {
            val cfg = loadConfig()
            val changed = ensureDisplay()
            canvasView.visibility = View.INVISIBLE   // so our own overlay isn't OCR'd
            delay(if (changed) 500 else 180)
            val bmp = grabFrame()
            if (bmp == null) { toast("تصویر صفحه گرفته نشد"); return }
            val res = recognizer.process(InputImage.fromBitmap(bmp, 0)).await()
            val blocks = res.textBlocks.filter { b ->
                b.boundingBox != null && b.text.length >= 2 && b.text.any { it in 'A'..'Z' || it in 'a'..'z' } &&
                        b.text.trim().split(Regex("\\s+")).size >= cfg.minWords
            }.sortedWith(compareBy({ it.boundingBox!!.top }, { it.boundingBox!!.left }))
            val texts = blocks.map { it.text.replace("\n", " ").trim() }
            val sig = texts.joinToString("|")
            if (isAuto && sig == lastSig) return
            if (texts.isEmpty()) {
                canvasView.setItems(emptyList()); lastSig = sig
                if (!isAuto) toast("متن انگلیسی پیدا نشد")
                return
            }
            val map = Translator.translate(cfg, texts)
            canvasView.scale = cfg.fontScale / 100f
            canvasView.setItems(blocks.mapIndexed { i, b ->
                TranslationView.Item(b.boundingBox!!, map[texts[i]] ?: texts[i], b.lines.size)
            })
            lastSig = sig
            clearJob?.cancel()
            if (!isAuto && cfg.clearSec > 0) clearJob = scope.launch {
                delay(cfg.clearSec * 1000L); clearTranslation()
            }
            lastErr = ""
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            val m = e.message ?: e.javaClass.simpleName
            if (m != lastErr) toast("خطا: $m")
            lastErr = m
        } finally {
            canvasView.visibility = View.VISIBLE
            busy = false
            runCounter++
        }
    }

    private fun clearTranslation() {
        canvasView.setItems(emptyList()); lastSig = ""; runCounter++   // runCounter++ makes auto mode re-baseline
    }

    private fun setMenu(show: Boolean) {
        menu.visibility = if (show) View.VISIBLE else View.GONE
        val lp = fabLp
        if (show) {
            val dm = metrics()
            lp.width = dp(210)
            lp.x = lp.x.coerceAtMost(dm.widthPixels - dp(214)).coerceAtLeast(0)
            lp.y = lp.y.coerceAtMost(dm.heightPixels - dp(56 + 3 * 46 + 24)).coerceAtLeast(0)
        } else lp.width = WindowManager.LayoutParams.WRAP_CONTENT
        wm.updateViewLayout(container, lp)
    }

    // ---------- smart auto mode ----------
    private fun sampleFrame(): ByteArray? = synchronized(lock) {
        val img = held ?: return@synchronized null
        val p = img.planes[0]; val buf = p.buffer; val rs = p.rowStride; val ps = p.pixelStride
        val gw = img.width / STEP; val gh = img.height / STEP
        val out = ByteArray(gw * gh)
        for (gy in 0 until gh) {
            val y = gy * STEP + STEP / 2
            for (gx in 0 until gw) {
                val i = y * rs + (gx * STEP + STEP / 2) * ps
                val lum = (buf.get(i).toInt() and 0xFF) + 2 * (buf.get(i + 1).toInt() and 0xFF) +
                        (buf.get(i + 2).toInt() and 0xFF)
                out[gy * gw + gx] = (lum shr 2).toByte()
            }
        }
        out
    }

    private fun changedRatio(a: ByteArray, b: ByteArray, thr: Int): Float {
        var c = 0
        for (i in a.indices) if (abs((a[i].toInt() and 0xFF) - (b[i].toInt() and 0xFF)) > thr) c++
        return c.toFloat() / a.size
    }

    /** Watches the screen cheaply; OCR+translate only when the picture changed AND settled. */
    private suspend fun smartLoop() = coroutineScope {
        var need = true
        var needSince = SystemClock.elapsedRealtime()
        var lastMove = needSince
        var prev: ByteArray? = null
        var base: ByteArray? = null
        var seen = runCounter
        while (isActive) {
            delay(300)
            if (busy) continue
            if (runCounter != seen) {            // a translation just finished (auto or manual)
                delay(300)
                base = withContext(Dispatchers.Default) { sampleFrame() }
                seen = runCounter; need = false; prev = null
                continue
            }
            val cur = withContext(Dispatchers.Default) { sampleFrame() } ?: continue
            val now = SystemClock.elapsedRealtime()
            if (!need) {
                val b = base
                if (b == null || b.size != cur.size) base = cur
                else if (changedRatio(b, cur, THR) > RATIO) { need = true; needSince = now; lastMove = now; prev = cur }
                continue
            }
            val pv = prev
            if (pv == null || pv.size != cur.size || changedRatio(pv, cur, THR) > RATIO) lastMove = now
            prev = cur
            if (now - lastMove >= loadConfig().settleMs || now - needSince >= 4000) runOnce(true)
        }
    }

    private fun setAuto(on: Boolean) {
        auto = on
        autoJob?.cancel()
        fab.text = if (on) "خودکار" else "ترجمه"
        (fab.background as GradientDrawable).setColor(if (on) 0xFF2E9E5B.toInt() else 0xFF2D6BFF.toInt())
        autoBtn.text = if (on) "حالت خودکار هوشمند: روشن ✓" else "حالت خودکار هوشمند: خاموش"
        if (on) autoJob = scope.launch { smartLoop() }
    }

    // ---------- overlay UI ----------
    private fun overlayType() = WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY

    private fun buildOverlay() {
        canvasView = TranslationView(this)
        val cp = WindowManager.LayoutParams(-1, -1, overlayType(),
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                    WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT)
        if (Build.VERSION.SDK_INT >= 28)
            cp.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
        wm.addView(canvasView, cp)

        fab = TextView(this).apply {
            text = "ترجمه"; setTextColor(Color.WHITE); textSize = 12f; gravity = Gravity.CENTER
            background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(0xFF2D6BFF.toInt()) }
            alpha = 0.88f
        }
        autoBtn = menuItem("حالت خودکار هوشمند: خاموش") { setAuto(!auto); setMenu(false) }
        menu = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; visibility = View.GONE
            addView(autoBtn)
            addView(menuItem("پاک کردن ترجمه") { clearJob?.cancel(); clearTranslation(); setMenu(false) })
            addView(menuItem("⏹ توقف و خروج") { stopSelf() })
        }
        container = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            addView(fab, LinearLayout.LayoutParams(dp(56), dp(56)))
            addView(menu)
        }
        val lp = WindowManager.LayoutParams(-2, -2, overlayType(),
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT).apply { gravity = Gravity.TOP or Gravity.START; x = dp(8); y = dp(160) }
        fabLp = lp
        wm.addView(container, lp)

        var dx = 0f; var dy = 0f; var sx = 0; var sy = 0; var moved = false; var longFired = false
        val longRun = Runnable {
            if (!moved) { longFired = true; setMenu(menu.visibility == View.GONE) }
        }
        fab.setOnTouchListener { _, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    dx = e.rawX; dy = e.rawY; sx = lp.x; sy = lp.y; moved = false; longFired = false
                    main.postDelayed(longRun, 600)
                }
                MotionEvent.ACTION_MOVE -> {
                    if (abs(e.rawX - dx) > 12 || abs(e.rawY - dy) > 12) { moved = true; main.removeCallbacks(longRun) }
                    if (moved) {
                        lp.x = sx + (e.rawX - dx).toInt(); lp.y = sy + (e.rawY - dy).toInt()
                        wm.updateViewLayout(container, lp)
                    }
                }
                MotionEvent.ACTION_UP -> {
                    main.removeCallbacks(longRun)
                    if (!moved && !longFired) {
                        if (menu.visibility == View.VISIBLE) setMenu(false)
                        else if (canvasView.hasItems()) { clearJob?.cancel(); clearTranslation() }   // tap = hide translation
                        else scope.launch { runOnce(false) }
                    }
                }
            }
            true
        }
    }

    private fun menuItem(t: String, onClick: () -> Unit) = TextView(this).apply {
        text = t; setTextColor(Color.WHITE); textSize = 13f
        setPadding(dp(14), dp(10), dp(14), dp(10))
        background = GradientDrawable().apply { cornerRadius = dp(10).toFloat(); setColor(0xEE10161E.toInt()) }
        layoutParams = LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(6) }
        gravity = Gravity.CENTER; layoutDirection = View.LAYOUT_DIRECTION_RTL; setSingleLine()
        setOnClickListener { onClick() }
    }

    override fun onDestroy() {
        autoJob?.cancel(); scope.cancel()
        try { wm.removeView(container); wm.removeView(canvasView) } catch (_: Exception) {}
        synchronized(lock) { held?.close(); held = null }
        vd?.release(); reader?.close(); projection?.stop()
        bgThread.quitSafely()
        super.onDestroy()
    }
}
