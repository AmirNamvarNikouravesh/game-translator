package ir.gametranslator

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.widget.*

class MainActivity : Activity() {
    private val REQ = 42

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val prefs = getSharedPreferences("cfg", Context.MODE_PRIVATE)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(24), dp(20), dp(24))
            layoutDirection = View.LAYOUT_DIRECTION_RTL
        }
        fun label(t: String) = TextView(this).apply { text = t; textSize = 15f; setPadding(0, dp(14), 0, dp(4)) }
        root.addView(TextView(this).apply { text = "مترجم بازی (انگلیسی ← فارسی)"; textSize = 22f })

        root.addView(label("موتور ترجمه"))
        val rg = RadioGroup(this)
        val rbG = RadioButton(this).apply { text = "گوگل (رایگان، تحت‌اللفظی)"; id = 1 }
        val rbA = RadioButton(this).apply { text = "Gemini (روان و طبیعی، با API key) ← پیشنهادی"; id = 2 }
        val rbO = RadioButton(this).apply { text = "OpenAI-سازگار (DeepSeek، Grok، OpenRouter، OpenAI و ...)"; id = 3 }
        rg.addView(rbG); rg.addView(rbA); rg.addView(rbO)
        rg.check(when (prefs.getString("engine", "google")) { "gemini" -> 2; "openai" -> 3; else -> 1 })
        root.addView(rg)

        root.addView(label("Gemini API key"))
        val key = EditText(this).apply {
            setText(prefs.getString("key", "")); layoutDirection = View.LAYOUT_DIRECTION_LTR
            inputType = InputType.TYPE_CLASS_TEXT; setSingleLine()
        }
        root.addView(key)

        root.addView(label("نام مدل Gemini"))
        val model = EditText(this).apply {
            setText((prefs.getString("model", Translator.DEFAULT_MODEL) ?: Translator.DEFAULT_MODEL)
                .let { if (it.startsWith("gemini-2")) Translator.DEFAULT_MODEL else it }); layoutDirection = View.LAYOUT_DIRECTION_LTR
            setSingleLine()
        }
        root.addView(model)

        val presets = listOf(
            "DeepSeek" to ("https://api.deepseek.com/v1" to "deepseek-chat"),
            "Grok (xAI)" to ("https://api.x.ai/v1" to "grok-4"),
            "OpenAI" to ("https://api.openai.com/v1" to "gpt-4o-mini"),
            "OpenRouter" to ("https://openrouter.ai/api/v1" to "deepseek/deepseek-chat"),
            "سفارشی (آدرس را خودتان بنویسید)" to ("" to "")
        )
        root.addView(label("سرویس OpenAI-سازگار: انتخاب از لیست (آدرس و مدل خودکار پر می‌شود)"))
        val spinner = Spinner(this).apply {
            adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item, presets.map { it.first })
            setSelection(prefs.getInt("opreset", 0).coerceIn(0, presets.size - 1))
        }
        root.addView(spinner)
        root.addView(label("آدرس API (Base URL)"))
        val oBase = EditText(this).apply {
            setText(prefs.getString("obase", presets[0].second.first)); layoutDirection = View.LAYOUT_DIRECTION_LTR; setSingleLine()
        }
        root.addView(oBase)
        root.addView(label("API key این سرویس"))
        val oKey = EditText(this).apply {
            setText(prefs.getString("okey", "")); layoutDirection = View.LAYOUT_DIRECTION_LTR
            inputType = InputType.TYPE_CLASS_TEXT; setSingleLine()
        }
        root.addView(oKey)
        root.addView(label("نام مدل این سرویس"))
        val oModel = EditText(this).apply {
            setText(prefs.getString("omodel", presets[0].second.second)); layoutDirection = View.LAYOUT_DIRECTION_LTR; setSingleLine()
        }
        root.addView(oModel)
        var firstSel = true
        spinner.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(p: AdapterView<*>?, v: View?, pos: Int, id: Long) {
                if (firstSel) { firstSel = false; return }          // keep saved values on startup
                val (base, mdl) = presets[pos].second
                if (base.isNotEmpty()) { oBase.setText(base); oModel.setText(mdl) }
            }
            override fun onNothingSelected(p: AdapterView<*>?) {}
        }

        root.addView(label("نام بازی / سبک (اختیاری، برای ترجمه دقیق‌تر). مثال: Skyrim, fantasy RPG"))
        val game = EditText(this).apply {
            setText(prefs.getString("game", "")); layoutDirection = View.LAYOUT_DIRECTION_LTR; setSingleLine()
        }
        root.addView(game)

        root.addView(label("اندازه متن ترجمه (درصد، پیش‌فرض ۱۳۰)"))
        val fontScale = EditText(this).apply {
            setText(prefs.getInt("fontScale", 130).toString()); inputType = InputType.TYPE_CLASS_NUMBER
            layoutDirection = View.LAYOUT_DIRECTION_LTR
        }
        root.addView(fontScale)

        root.addView(label("پاک شدن خودکار ترجمه در حالت دستی بعد از چند ثانیه (۰ = خاموش)"))
        val clearSec = EditText(this).apply {
            setText(prefs.getInt("clearSec", 0).toString()); inputType = InputType.TYPE_CLASS_NUMBER
            layoutDirection = View.LAYOUT_DIRECTION_LTR
        }
        root.addView(clearSec)

        root.addView(label("حداقل تعداد کلمه برای ترجمه (۱ = همه چیز، حتی دکمه‌ها. ۲ = فقط جمله‌ها)"))
        val minWords = EditText(this).apply {
            setText(prefs.getInt("minWordsV2", 1).toString()); inputType = InputType.TYPE_CLASS_NUMBER
            layoutDirection = View.LAYOUT_DIRECTION_LTR
        }
        root.addView(minWords)

        val casual = CheckBox(this).apply {
            text = "لحن محاوره‌ای (مثل حرف زدن روزمره، فقط Gemini)"; isChecked = prefs.getBoolean("casual", true)
        }
        root.addView(casual, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(12) })

        val ignoreNames = CheckBox(this).apply {
            text = "نادیده گرفتن نام کاراکتر بالای دیالوگ (فقط صحبت‌ها ترجمه شوند)"; isChecked = prefs.getBoolean("ignoreNames", true)
        }
        root.addView(ignoreNames, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(8) })
        val clearNames = Button(this).apply { text = "پاک کردن لیست نام‌های یادگرفته‌شده" }
        clearNames.setOnClickListener {
            prefs.edit().remove("names").apply()
            Toast.makeText(this, "لیست نام‌ها پاک شد", Toast.LENGTH_SHORT).show()
        }
        root.addView(clearNames)

        root.addView(label("مدت ثبات تصویر قبل از ترجمه خودکار (میلی‌ثانیه)"))
        val interval = EditText(this).apply {
            setText(prefs.getInt("settle", 600).toString()); inputType = InputType.TYPE_CLASS_NUMBER
            layoutDirection = View.LAYOUT_DIRECTION_LTR
        }
        root.addView(interval)

        val start = Button(this).apply { text = "شروع (نمایش دکمه شناور)" }
        root.addView(start, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(24) })
        val stop = Button(this).apply { text = "⏹ توقف و بستن دکمه شناور" }
        root.addView(stop, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(8) })
        stop.setOnClickListener {
            stopService(Intent(this, OverlayService::class.java))
            Toast.makeText(this, "متوقف شد", Toast.LENGTH_SHORT).show()
        }
        root.addView(TextView(this).apply {
            text = "بعد از شروع، بازی را باز کنید. ضربه روی دکمه = ترجمه یک‌بار.\nضربه دوباره وقتی ترجمه روی صفحه است = پاک شدن ترجمه.\nنگه‌داشتن دکمه = منو (حالت خودکار هوشمند، رسم/ویرایش کادر، روشن/خاموش کردن کادر، پاک‌کردن، توقف).\nکادر ترجمه: از منو «رسم / ویرایش کادر» را بزنید و کادر را دور متن گفتگو بکشید (با انگشت جابه‌جا و تغییر اندازه دهید). بعد از تأیید فقط داخل کادر ترجمه می‌شود.\nکلید Gemini را از aistudio.google.com/apikey بگیرید."
            textSize = 13f; gravity = Gravity.START; setPadding(0, dp(16), 0, 0)
        })

        start.setOnClickListener {
            prefs.edit()
                .putString("engine", when (rg.checkedRadioButtonId) { 2 -> "gemini"; 3 -> "openai"; else -> "google" })
                .putString("obase", oBase.text.toString().trim())
                .putString("okey", oKey.text.toString().trim())
                .putString("omodel", oModel.text.toString().trim())
                .putInt("opreset", spinner.selectedItemPosition)
                .putString("key", key.text.toString().trim())
                .putString("model", model.text.toString().trim().ifBlank { Translator.DEFAULT_MODEL })
                .putString("game", game.text.toString().trim())
                .putInt("fontScale", fontScale.text.toString().toIntOrNull()?.coerceIn(60, 300) ?: 130)
                .putInt("clearSec", clearSec.text.toString().toIntOrNull()?.coerceIn(0, 120) ?: 0)
                .putInt("minWordsV2", minWords.text.toString().toIntOrNull()?.coerceIn(1, 10) ?: 1)
                .putBoolean("casual", casual.isChecked)
                .putBoolean("ignoreNames", ignoreNames.isChecked)
                .putInt("settle", interval.text.toString().toIntOrNull()?.coerceIn(200, 3000) ?: 600)
                .apply()
            if (!Settings.canDrawOverlays(this)) {
                Toast.makeText(this, "اجازه «نمایش روی سایر برنامه‌ها» را بدهید و دوباره شروع را بزنید", Toast.LENGTH_LONG).show()
                startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
                return@setOnClickListener
            }
            if (Build.VERSION.SDK_INT >= 33) requestPermissions(arrayOf("android.permission.POST_NOTIFICATIONS"), 1)
            val mpm = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
            startActivityForResult(mpm.createScreenCaptureIntent(), REQ)
        }
        setContentView(ScrollView(this).apply { addView(root) })
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == REQ && resultCode == RESULT_OK && data != null) {
            startForegroundService(Intent(this, OverlayService::class.java)
                .putExtra("code", resultCode).putExtra("data", data))
            moveTaskToBack(true)
        }
    }
}
