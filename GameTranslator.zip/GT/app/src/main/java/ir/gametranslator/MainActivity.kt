package ir.gametranslator

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.widget.*

class MainActivity : Activity() {
    private val REQ = 42

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val prefs = getSharedPreferences("cfg", Context.MODE_PRIVATE)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(24), dp(20), dp(24))
            layoutDirection = View.LAYOUT_DIRECTION_RTL
        }
        fun label(t: String) = TextView(this).apply { text = t; textSize = 15f; setPadding(0, dp(14), 0, dp(4)) }
        root.addView(TextView(this).apply { text = "مترجم بازی (انگلیسی ← فارسی)"; textSize = 22f })

        root.addView(label("موتور ترجمه"))
        val rg = RadioGroup(this)
        val rbG = RadioButton(this).apply { text = "گوگل (رایگان، بدون کلید)"; id = 1 }
        val rbA = RadioButton(this).apply { text = "هوش مصنوعی Gemini (روان‌تر، با API key)"; id = 2 }
        rg.addView(rbG); rg.addView(rbA)
        rg.check(if (prefs.getString("engine", "google") == "gemini") 2 else 1)
        root.addView(rg)

        root.addView(label("Gemini API key"))
        val key = EditText(this).apply {
            setText(prefs.getString("key", "")); layoutDirection = View.LAYOUT_DIRECTION_LTR
            inputType = InputType.TYPE_CLASS_TEXT; setSingleLine()
        }
        root.addView(key)

        root.addView(label("نام مدل Gemini"))
        val model = EditText(this).apply {
            setText((prefs.getString("model", Translator.DEFAULT_MODEL) ?: Translator.DEFAULT_MODEL)
                .let { if (it.startsWith("gemini-2")) Translator.DEFAULT_MODEL else it }); layoutDirection = View.LAYOUT_DIRECTION_LTR
            setSingleLine()
        }
        root.addView(model)

        root.addView(label("نام بازی / سبک (اختیاری، برای ترجمه دقیق‌تر). مثال: Skyrim, fantasy RPG"))
        val game = EditText(this).apply {
            setText(prefs.getString("game", "")); layoutDirection = View.LAYOUT_DIRECTION_LTR; setSingleLine()
        }
        root.addView(game)

        root.addView(label("مدت ثبات تصویر قبل از ترجمه خودکار (میلی‌ثانیه)"))
        val interval = EditText(this).apply {
            setText(prefs.getInt("settle", 600).toString()); inputType = InputType.TYPE_CLASS_NUMBER
            layoutDirection = View.LAYOUT_DIRECTION_LTR
        }
        root.addView(interval)

        val start = Button(this).apply { text = "شروع (نمایش دکمه شناور)" }
        root.addView(start, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(24) })
        val stop = Button(this).apply { text = "⏹ توقف و بستن دکمه شناور" }
        root.addView(stop, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(8) })
        stop.setOnClickListener {
            stopService(Intent(this, OverlayService::class.java))
            Toast.makeText(this, "متوقف شد", Toast.LENGTH_SHORT).show()
        }
        root.addView(TextView(this).apply {
            text = "بعد از شروع، بازی را باز کنید. ضربه روی دکمه = ترجمه یک‌بار.\nنگه‌داشتن دکمه = منو (حالت خودکار هوشمند، پاک‌کردن، توقف).\nکلید Gemini را از aistudio.google.com/apikey بگیرید."
            textSize = 13f; gravity = Gravity.START; setPadding(0, dp(16), 0, 0)
        })

        start.setOnClickListener {
            prefs.edit()
                .putString("engine", if (rg.checkedRadioButtonId == 2) "gemini" else "google")
                .putString("key", key.text.toString().trim())
                .putString("model", model.text.toString().trim().ifBlank { Translator.DEFAULT_MODEL })
                .putString("game", game.text.toString().trim())
                .putInt("settle", interval.text.toString().toIntOrNull()?.coerceIn(200, 3000) ?: 600)
                .apply()
            if (!Settings.canDrawOverlays(this)) {
                Toast.makeText(this, "اجازه «نمایش روی سایر برنامه‌ها» را بدهید و دوباره شروع را بزنید", Toast.LENGTH_LONG).show()
                startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
                return@setOnClickListener
            }
            if (Build.VERSION.SDK_INT >= 33) requestPermissions(arrayOf("android.permission.POST_NOTIFICATIONS"), 1)
            val mpm = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
            startActivityForResult(mpm.createScreenCaptureIntent(), REQ)
        }
        setContentView(ScrollView(this).apply { addView(root) })
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == REQ && resultCode == RESULT_OK && data != null) {
            startForegroundService(Intent(this, OverlayService::class.java)
                .putExtra("code", resultCode).putExtra("data", data))
            moveTaskToBack(true)
        }
    }
}
