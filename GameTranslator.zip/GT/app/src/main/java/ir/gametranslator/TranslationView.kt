package ir.gametranslator

import android.content.Context
import android.graphics.*
import android.text.Layout
import android.text.StaticLayout
import android.text.TextDirectionHeuristics
import android.text.TextPaint
import android.view.View
import kotlin.math.max

class TranslationView(ctx: Context) : View(ctx) {
    data class Item(val rect: Rect, val text: String)

    private var items = listOf<Item>()
    private val bg = Paint().apply { color = 0xEE10161E.toInt() }
    private val tp = TextPaint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.WHITE }

    fun setItems(list: List<Item>) { items = list; invalidate() }

    override fun onDraw(c: Canvas) {
        for (item in items) {
            val r = Rect(item.rect).apply { inset(-6, -4) }
            val w = max(r.width(), 200).coerceAtMost(width)
            val left = if (r.left + w > width) width - w else max(r.left, 0)
            var layout: StaticLayout? = null
            var size = 44f
            while (size >= 18f) {
                tp.textSize = size
                layout = build(item.text, w - 16)
                if (layout.height <= r.height()) break
                size -= 2f
            }
            val l = layout ?: continue
            val boxH = max(r.height(), l.height + 8)
            c.drawRoundRect(left.toFloat(), r.top.toFloat(), (left + w).toFloat(),
                (r.top + boxH).toFloat(), 10f, 10f, bg)
            c.save()
            c.translate((left + 8).toFloat(), r.top + (boxH - l.height) / 2f)
            l.draw(c)
            c.restore()
        }
    }

    private fun build(t: String, w: Int): StaticLayout =
        StaticLayout.Builder.obtain(t, 0, t.length, tp, w)
            .setAlignment(Layout.Alignment.ALIGN_CENTER)
            .setTextDirection(TextDirectionHeuristics.RTL)
            .build()
}
