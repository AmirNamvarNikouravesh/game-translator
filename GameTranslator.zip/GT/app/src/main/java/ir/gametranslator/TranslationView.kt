package ir.gametranslator

import android.content.Context
import android.graphics.*
import android.text.Layout
import android.text.StaticLayout
import android.text.TextDirectionHeuristics
import android.text.TextPaint
import android.view.View
import kotlin.math.max

class TranslationView(ctx: Context) : View(ctx) {
    data class Item(val rect: Rect, val text: String, val lines: Int)

    var scale = 1.3f
    private var items = listOf<Item>()
    private val d = resources.displayMetrics.density
    private val bg = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xE610161E.toInt() }
    private val tp = TextPaint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.WHITE }

    fun setItems(list: List<Item>) { items = list; invalidate() }
    fun hasItems() = items.isNotEmpty()

    override fun onDraw(c: Canvas) {
        val pad = 10 * d
        for (item in items) {
            val r = item.rect
            val lineH = r.height() / max(1, item.lines).toFloat()
            tp.textSize = (lineH * 0.9f).coerceIn(12 * d, 26 * d) * scale
            val w = (r.width() * 1.1f).coerceAtLeast(130 * d).coerceAtMost(width - 8f).toInt()
            val l = StaticLayout.Builder.obtain(item.text, 0, item.text.length, tp, (w - 2 * pad).toInt())
                .setAlignment(Layout.Alignment.ALIGN_CENTER)
                .setTextDirection(TextDirectionHeuristics.RTL)
                .setLineSpacing(0f, 1.15f)
                .setBreakStrategy(Layout.BREAK_STRATEGY_BALANCED)
                .build()
            val boxH = max(r.height().toFloat(), l.height + 2 * pad)
            val left = (r.exactCenterX() - w / 2f).coerceIn(4f, max(4f, width - w - 4f))
            val top = r.top.toFloat().coerceIn(0f, max(0f, height - boxH))
            c.drawRoundRect(left, top, left + w, top + boxH, 14f, 14f, bg)
            c.save()
            c.translate(left + pad, top + (boxH - l.height) / 2f)
            l.draw(c)
            c.restore()
        }
    }
}
